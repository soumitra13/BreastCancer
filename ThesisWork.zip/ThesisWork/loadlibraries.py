
import numpy as np
import pandas
from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
import time
#import MLP

#print(dir(MLP))
# Load dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data"
#names = ['ID No.', 'Clump Thickness', 'Uniformity of Cell Size', 'Uniformity of Cell Shape', 'Marginal Adhesion', 'Single Epithelial Cell Size','Bare Nuclei','Bland Chromatin', 'Normal Nucleoli','Mitoses','class']
names = ['ID', 'CT', 'UCSI', 'UCSH', 'MA', 'SECS','BN','BC', 'NN','Mi','class']
dataset = pandas.read_csv(url, names = names)
#names = ['ID', 'CT', 'UCSI', 'UCSH', 'MA', 'SECS','BN','BC', 'NN','Mi','class']
#dataset = pandas.concat(map(lambda x: pandas.read_csv(url, names=names)))
dataset.replace("?", np.nan, inplace = True)
dataset.isnull().sum()
dataset = dataset.fillna(0)

#shape
print(dataset.shape)


#head
print(dataset.head(30))
#dataset = dataset.fillna(0)
##print(dataset.isnull().sum())

dataset['BN'] = dataset['BN'].astype(float)
#dataset = dataset.set_index('ID')
#del dataset['Unnamed: 32']

print(dataset.info())
#dataset[['ID No.']] = dataset[['ID No.']].astype(int)
#dataset[['Clump Thickness', 'Uniformity of Cell Size', 'Uniformity of Cell Shape', 'Marginal Adhesion', 'Single Epithelial Cell Size','Bare Nuclei','Bland Chromatin', 'Normal Nucleoli','Mitoses','class']] = dataset[['Clump Thickness', 'Uniformity of Cell Size', 'Uniformity of Cell Shape', 'Marginal Adhesion', 'Single Epithelial Cell Size','Bare Nuclei','Bland Chromatin', 'Normal Nucleoli','Mitoses']].astype(int)
#dataset[['class']].replace(to_replace=[2,4], value =1, inplace=True)
#description
print(dataset.describe())

#class distribution
print(dataset.groupby('class').size())

#box and whisker plots
dataset.plot(kind='box', subplots=True, layout=(6,2), sharex=False, sharey=False)
plt.show()

#histograms
dataset.hist()
plt.show()

#scatter plot matrix
scatter_matrix(dataset)
plt.show()

#split-out validation dataset
array = dataset.values
X = array[:, 0:10]
Y = array[:,10]
#validation_size = 0.20
#seed = 7
X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2,random_state=7)

#Test options and evaluation metric
#seed = 7
#scoring = 'accuracy'

#spot check algorithms
models_list = []
#models_list.append(('LR', LogisticRegression()))
#models_list.append(('LDA', LinearDiscriminantAnalysis()))
#models_list.append(('KNN', KNeighborsClassifier()))
models_list.append(('DecisionTree Classifier', DecisionTreeClassifier()))
#models_list.append(('NB', GaussianNB()))
models_list.append(('SupportVectorMachines', SVC()))
models_list.append(('MultiLayer Perceptron', MLPClassifier()))
#evaluate each model in turn

num_splits = 10
results = []
names = []
#print("Executed before for loop");
for name, model in models_list:
    kfold = KFold(n_splits=num_splits, random_state=7)
    start = time.time()
    cv_results = cross_val_score(model, X_train, Y_train, cv=kfold, scoring='accuracy')
    end = time.time()
    results.append(cv_results)
    names.append(name)
    msg = "%s : %f(%f) (run time: %f)" % (name, cv_results.mean(), cv_results.std(),end-start)
    print(msg)
#print(dataset.info())
